# E3 Mobile Learning Materials

A reusable React Native package for displaying learning materials (PDF, JPG, PNG) in GRM mobile apps. Supports audience targeting (facilitator / citizen / both).

## Installation

```bash
npm install e3-mobile-learning-materials
# or
yarn add e3-mobile-learning-materials
```

### Peer Dependencies

Ensure these are installed in your host app:

- `react` >= 18.0.0
- `react-native` >= 0.74.0
- `react-native-paper` >= 4.0.0
- `@react-navigation/native` >= 7.0.0
- `@react-navigation/stack` >= 7.0.0
- `@react-native-async-storage/async-storage` >= 1.23.0
- `expo-file-system` >= 17.0.0
- `@expo/vector-icons` >= 14.0.0

## Quick Start

### 1. Configure the API client

Call this once at app startup (e.g., in `App.js` or `index.js`):

```tsx
import { configureLearningMaterialsApi } from 'e3-mobile-learning-materials';

configureLearningMaterialsApi({
  baseURL: 'https://your-api.example.com',
  getAuthHeaders: async () => {
    const token = await getAuthToken(); // your auth logic
    return { Authorization: `Bearer ${token}` };
  },
});
```

### 2. Register navigation screens

Add these screens to your navigation stack:

```tsx
import { LearningMaterialsScreen, LearningMaterialDetailScreen } from 'e3-mobile-learning-materials';

// In your navigator:
<Stack.Screen
  name="LearningMaterials"
  component={LearningMaterialsScreen}
  initialParams={{ audience: 'facilitator', title: 'Mes formations' }}
/>
<Stack.Screen
  name="LearningMaterialDetail"
  component={LearningMaterialDetailScreen}
/>
```

### 3. For facilitators (filtered view)

```tsx
<LearningMaterialsScreen
  audience="facilitator"
  title="Documents du facilitateur"
/>
```

### 4. For citizens (filtered view)

```tsx
<LearningMaterialsScreen
  audience="citizen"
  title="Documents citoyens"
/>
```

## Using Components Directly

You can use the lower-level components if you need custom layouts:

```tsx
import {
  LearningMaterialsList,
  useLearningMaterials,
  LearningMaterialViewer,
} from 'e3-mobile-learning-materials';

function MyFacilitatorScreen() {
  const { materials, loading, refreshing, error, hasMore, fetchMore, refresh } =
    useLearningMaterials('facilitator');

  return (
    <LearningMaterialsList
      materials={materials}
      loading={loading}
      refreshing={refreshing}
      error={error}
      hasMore={hasMore}
      onRefresh={refresh}
      onLoadMore={fetchMore}
      onMaterialPress={(material) => navigation.navigate('Detail', { materialId: material.id })}
    />
  );
}
```

## API

### `configureLearningMaterialsApi(config: ApiConfig)`

Configure the API client. Must be called before using any hooks or screens.

### `useLearningMaterials(audience?: LearningMaterialAudience, categories?: string[])`

React hook for fetching a paginated list of learning materials.

Returns: `{ materials, loading, refreshing, error, hasMore, fetchMore, refresh, availableCategories }`

### `useLearningMaterialDetail(id: string)`

React hook for fetching a single learning material by ID.

Returns: `{ material, loading, error }`

## WatermelonDB Integration (Optional)

If your app uses WatermelonDB for offline storage, the package provides optional integration:

```tsx
import { learningMaterialTableSchema } from 'e3-mobile-learning-materials/watermelon';
import { appSchema } from '@nozbe/watermelondb';

export default appSchema({
  version: 2,
  tables: [
    // ... existing tables
    learningMaterialTableSchema,
  ],
});
```

```tsx
import { LearningMaterialLocalModel } from 'e3-mobile-learning-materials/watermelon';

// Add to modelClasses:
modelClasses: [
  // ... existing models
  LearningMaterialLocalModel,
],
```

```tsx
import { createLearningMaterialSyncable } from 'e3-mobile-learning-materials/watermelon';
import { getApiClient } from 'e3-mobile-learning-materials';
import { database } from './database';

syncServiceInstance.register(
  createLearningMaterialSyncable(database, getApiClient())
);
```

## Development

```bash
# Install dependencies
yarn install

# Build
yarn build

# Lint
yarn lint

# Test
yarn test
```

## License

MIT
